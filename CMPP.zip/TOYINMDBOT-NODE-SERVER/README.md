# TOYINMDBOT Node.js backend (multi-session)

This package runs the WhatsApp/Baileys backend. Each browser visitor has a random 128-bit session ID and a separate directory under `AUTH_DIR`. The session ID is a bearer secret: visitors should not share it. The configured `MAX_SESSIONS` is a hard cap, not a promise of unlimited concurrent WhatsApp accounts.

## Requirements
- Node.js 20 or newer
- A persistent Pterodactyl volume/directory for `auth_sessions`
- A reachable public HTTPS origin for the Cloudflare Worker to proxy to
- A long random `PAIRING_PROXY_TOKEN` shared with the Cloudflare Worker

## Install on Pterodactyl
1. Create a Node.js server using Node 20+ and allocate TCP port **2008** (or set `PORT` to the allocated port).
2. Upload the contents of this ZIP into the server root. `package.json` must be at the root, not inside an extra nested folder.
3. Copy `.env.example` to `.env` and configure every value below.
4. This package includes a project `.npmrc` enabling Git dependencies required transitively by Baileys on npm 12+. Keep this file beside `package.json`. Then run `npm install` (or use the egg's install step) and set startup to `npm start`.
5. Ensure the server's allocated port matches `PORT`. Keep `AUTH_DIR=./auth_sessions` on persistent storage.
6. Start the server and check `https://YOUR_BACKEND_ORIGIN/health`. It should report `sessionMode: "multi-session"`.

## Environment variables
| Variable | Required | Meaning |
|---|---|---|
| `PORT` | Yes | Pterodactyl allocated port; default 2008 |
| `HOST` | No | Bind address; default `0.0.0.0` |
| `AUTH_DIR` | No | Persistent per-visitor credentials root; default `./auth_sessions` |
| `PAIRING_PROXY_TOKEN` | Yes | Long random secret; must exactly match Cloudflare Worker secret |
| `MAX_SESSIONS` | No | Maximum active/known visitor sessions; default 10 |
| `PAIR_RATE_LIMIT` | No | Pairing/API requests per IP per window; default 5 |
| `PAIR_RATE_WINDOW_MS` | No | Rate-limit window; default 900000 ms |
| `PAIRING_TIMEOUT_MS` | No | Pair-code request timeout; default 10000 ms |
| `UNPAIRED_SESSION_TTL_MS` | No | Cleanup delay for unlinked sessions; default 1800000 ms |
| `OWNER_NUMBER` | No | Bot owner number with country code, digits only |
| `PREFIX` | No | Bot command prefix; default `.` |
| `BOT_MODE` | No | Initial bot mode; default `public` |
| `LOG_LEVEL` | No | Pino log level; default `warn` |

Generate a secret locally with `openssl rand -hex 32`. Do not put it in the frontend ZIP, browser JavaScript, public GitHub repository, or a screenshot. Set it as a Pterodactyl environment variable and as a Cloudflare Worker secret.

## API routes (proxied through Worker)
- `POST /api/pair` body: `{ "number": "2348012345678", "sessionId": "32-character-lowercase-hex" }`
- `GET /api/status?sessionId=...`
- `POST /api/disconnect` body: `{ "sessionId": "..." }`

The Worker adds the backend secret and client IP. Do not expose the backend secret in browser requests. The session ID is a private bearer token for that visitor. Clearing browser storage loses access to that session; an unpaired session is automatically cleaned after the configured TTL. Connected sessions persist on disk and are restored after a process restart.

## Multi-session behavior and limitations
- Every visitor/browser profile gets its own Baileys socket and auth directory.
- Bot command handling is attached independently to each socket. Anti-delete cache, anti-link settings, anti-delete settings, and mode settings are scoped to the visitor session.
- A visitor can only manage a session while retaining its session ID in that browser's local storage.
- The in-memory IP rate limiter is per process; for multi-instance deployments, add a shared rate-limit store and sticky routing. Run one backend process/replica unless you have designed shared coordination.
- WhatsApp/Baileys is an unofficial integration. WhatsApp may rate-limit or log out linked devices. Use only accounts you control and comply with WhatsApp terms.
- A pairing timeout cannot guarantee WhatsApp is reachable; check Pterodactyl logs and retry after the temporary session is cleaned.

## npm 12 Git dependency note
The `.npmrc` file sets `allow-git=all` because the Baileys dependency tree includes a Git-hosted `libsignal` package. npm 12 disables Git dependencies by default, which otherwise causes `EALLOWGIT` and leaves packages such as `dotenv` uninstalled. This setting permits Git dependencies declared by packages in the dependency tree; keep dependencies trusted and do not add unknown packages.

## Checks
Run `npm install`, then `npm run check`. `npm run check` performs Node syntax checks. A successful health check confirms the HTTP server is running; it does not prove WhatsApp pairing until tested with a real account.
