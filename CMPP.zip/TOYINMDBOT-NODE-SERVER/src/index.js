require('dotenv').config();
const express = require('express');
const crypto = require('crypto');
const path = require('path');
const fs = require('fs');
const { startSession, removeSession, restoreSessions, shutdownSessions, getSession, getCounts } = require('./lib/session-manager');

const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '8kb', strict: true }));
const PORT = Number(process.env.PORT || 2008);
const HOST = process.env.HOST || '0.0.0.0';
const TOKEN = process.env.PAIRING_PROXY_TOKEN || '';
const rate = new Map();
const WINDOW = Math.max(60000, Number(process.env.PAIR_RATE_WINDOW_MS || 900000));
const LIMIT = Math.max(1, Number(process.env.PAIR_RATE_LIMIT || 5));
const SESSION_RE = /^[a-f0-9]{32}$/;

function fail(res, status, error) { return res.status(status).json({ ok: false, error }); }
function proxyAuth(req, res, next) {
  if (!TOKEN) return fail(res, 503, 'Pairing service is not configured by the administrator.');
  const a = Buffer.from(String(req.get('x-toyin-proxy-token') || ''));
  const b = Buffer.from(TOKEN);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return fail(res, 403, 'Unauthorized website proxy.');
  next();
}
function visitorKey(req) { return String(req.get('x-toyin-client-ip') || req.ip || 'unknown').slice(0, 100); }
function limit(req, res, next) {
  const now = Date.now(), key = visitorKey(req);
  let item = rate.get(key);
  if (!item || now - item.start >= WINDOW) item = { start: now, count: 0 };
  item.count++; rate.set(key, item);
  if (item.count > LIMIT) { res.set('Retry-After', String(Math.ceil((WINDOW - (now-item.start))/1000))); return fail(res, 429, 'Too many requests. Please wait before trying again.'); }
  if (rate.size > 10000) for (const [k,v] of rate) if (now-v.start > WINDOW) rate.delete(k);
  next();
}
function sessionId(req, res) {
  const id = String(req.body?.sessionId || req.query?.sessionId || req.get('x-toyin-session') || '');
  if (!SESSION_RE.test(id)) { fail(res, 400, 'Invalid visitor session. Refresh the website and try again.'); return null; }
  return id;
}
app.get('/health', (_req,res) => res.json({ ok: true, bot: 'TOYINMDBOT', sessionMode: 'multi-session', ...getCounts() }));
app.use('/api', proxyAuth);
app.post('/api/pair', limit, async (req,res) => {
  const id = sessionId(req,res); if (!id) return;
  const number = typeof req.body?.number === 'string' ? req.body.number.replace(/\D/g,'') : '';
  if (number.length < 10 || number.length > 15) return fail(res,400,'Enter a valid WhatsApp number with country code (10–15 digits).');
  try {
    const code = await startSession(id, number);
    if (!code) return fail(res,409,'A registered session already exists for this visitor.');
    return res.json({ ok: true, code, status: 'awaiting_link' });
  } catch (e) { console.error('Pair request:', e.message); return fail(res,e.status || 502,e.status === 504 ? 'Pairing request timed out. The temporary session was closed; please try again.' : e.message || 'Could not create a pairing code.'); }
});
app.get('/api/status', (req,res) => {
  const id = sessionId(req,res); if (!id) return;
  return res.json({ ok:true, session: getSession(id) || { sessionId:id, status:'not_started', connected:false } });
});
app.post('/api/disconnect', limit, async (req,res) => {
  const id = sessionId(req,res); if (!id) return;
  await removeSession(id, true);
  return res.json({ ok:true, status:'disconnected' });
});
app.use((err,_req,res,_next) => { console.error('HTTP error:',err.message); if (res.headersSent) return; fail(res,400,'Invalid request body.'); });

const server = app.listen(PORT, HOST, async () => {
  fs.mkdirSync(path.resolve(process.env.AUTH_DIR || './auth_sessions'), { recursive:true, mode:0o700 });
  console.log(`TOYINMDBOT API listening on ${HOST}:${PORT} (multi-session)`);
  await restoreSessions();
});
let closing = false;
async function shutdown(signal) {
  if (closing) return; closing = true; console.log(`${signal}: stopping TOYINMDBOT`);
  await shutdownSessions(); server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 5000).unref();
}
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
