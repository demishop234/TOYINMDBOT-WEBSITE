const fs = require('fs');
const path = require('path');
const vm = require('vm');
const root = path.join(__dirname, '..', 'src');
let count = 0;
function walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const file = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(file);
    else if (entry.isFile() && file.endsWith('.js')) {
      new vm.Script(fs.readFileSync(file, 'utf8'), { filename: file });
      count++;
    }
  }
}
walk(root);
console.log(`Syntax check passed for ${count} backend JavaScript files.`);
